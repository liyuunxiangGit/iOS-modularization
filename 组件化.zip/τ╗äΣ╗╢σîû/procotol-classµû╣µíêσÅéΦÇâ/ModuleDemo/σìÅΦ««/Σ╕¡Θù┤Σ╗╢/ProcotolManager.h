//
//  ProcotolManager.h
//  ModuleDemo
//
//  Created by 赵琛 on 2017/5/9.
//  Copyright © 2017年 赵琛. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ProcotolManager : NSObject

+ (ProcotolManager *)sharedManger;

- (void)registServiceProvide:(id)provide forProcotol:(Protocol *)procotol;

- (id)serviceProvideForProcotol:(Protocol *)procotol;

@end
