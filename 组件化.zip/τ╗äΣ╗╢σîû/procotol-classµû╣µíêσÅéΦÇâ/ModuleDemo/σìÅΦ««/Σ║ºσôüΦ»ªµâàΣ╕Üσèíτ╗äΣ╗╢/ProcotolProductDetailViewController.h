//
//  ProcotolProductDetailViewController.h
//  ModuleDemo
//
//  Created by 赵琛 on 2017/5/9.
//  Copyright © 2017年 赵琛. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProcotolProductDetailViewController : UIViewController


@property (nonatomic,strong)NSString *productId;

@end
