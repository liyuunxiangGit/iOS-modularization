//
//  UrlProductDetailViewController.h
//  ModuleDemo
//
//  Created by 赵琛 on 2017/5/10.
//  Copyright © 2017年 赵琛. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UrlProductDetailViewController : UIViewController

@property (nonatomic,strong)NSString *productName;

@end
