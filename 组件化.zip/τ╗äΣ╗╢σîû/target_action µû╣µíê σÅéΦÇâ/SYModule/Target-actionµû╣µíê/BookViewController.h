//
//  BookViewController.h
//  SYModule
//
//  Created by Shen Yuan on 2017/11/25.
//  Copyright © 2017年 Shen Yuan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BookViewController : UIViewController
@property (nonatomic,copy)NSString *bookId;

@property (nonatomic,copy)NSString *bookName;
@end
